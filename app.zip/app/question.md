1) create docker compose to run simple web page with port 3000

-give index.js code
-give docker-compose.yml

2) create nginx container and do reverse proxy configuration to listen 